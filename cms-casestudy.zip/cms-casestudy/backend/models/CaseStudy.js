import mongoose from 'mongoose';

const caseStudySchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    titulo: {
      type: String,
      required: true
    },
    slug: {
      type: String,
      required: true,
      unique: true
    },
    blocks: {
      type: mongoose.Schema.Types.Mixed,
      default: []
    },
    globalStyles: {
      type: mongoose.Schema.Types.Mixed,
      default: {}
    }
  },
  {
    timestamps: true
  }
);

const CaseStudy = mongoose.model('CaseStudy', caseStudySchema);
export default CaseStudy;