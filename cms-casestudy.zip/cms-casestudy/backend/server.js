import express from 'express';
import cors from 'cors';
import mongoose from 'mongoose';
import dotenv from 'dotenv';

import authRoutes from './routes/auth.js';
import caseRoutes from './routes/caseStudies.js';
import CaseStudy from './models/CaseStudy.js';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json({ limit: '10mb' }));

// Conectar a MongoDB
mongoose
  .connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
  })
  .then(() => console.log('Conectado a MongoDB'))
  .catch((err) => console.error('Error al conectar a MongoDB:', err));

// Rutas
app.use('/api/auth', authRoutes);
app.use('/api/case-studies', caseRoutes);

// Ruta pública para obtener caso por slug
app.get('/api/public/:slug', async (req, res) => {
  try {
    const caso = await CaseStudy.findOne({ slug: req.params.slug });
    if (!caso) {
      return res.status(404).json({ mensaje: 'Caso no encontrado' });
    }
    return res.json({ titulo: caso.titulo, blocks: caso.blocks, globalStyles: caso.globalStyles });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ mensaje: 'Error en el servidor' });
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Servidor ejecutándose en el puerto ${PORT}`));