import express from 'express';
import CaseStudy from '../models/CaseStudy.js';
import auth from '../middleware/auth.js';

const router = express.Router();

// Listar casos del usuario
router.get('/', auth, async (req, res) => {
  try {
    const casos = await CaseStudy.find({ user: req.user.id }).sort({ createdAt: -1 });
    return res.json(casos);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ mensaje: 'Error en el servidor' });
  }
});

// Crear caso
router.post('/', auth, async (req, res) => {
  try {
    const { titulo, blocks, globalStyles } = req.body;
    if (!titulo) {
      return res.status(400).json({ mensaje: 'El título es obligatorio' });
    }
    // generar slug unico
    const baseSlug = titulo.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9\-]/g, '');
    let slug = baseSlug;
    let counter = 1;
    // Ensure uniqueness
    while (await CaseStudy.findOne({ slug, user: req.user.id })) {
      slug = `${baseSlug}-${counter}`;
      counter++;
    }
    const caso = await CaseStudy.create({ user: req.user.id, titulo, slug, blocks: blocks || [], globalStyles: globalStyles || {} });
    return res.status(201).json(caso);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ mensaje: 'Error en el servidor' });
  }
});

// Obtener un caso por id
router.get('/:id', auth, async (req, res) => {
  try {
    const caso = await CaseStudy.findOne({ _id: req.params.id, user: req.user.id });
    if (!caso) {
      return res.status(404).json({ mensaje: 'Caso no encontrado' });
    }
    return res.json(caso);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ mensaje: 'Error en el servidor' });
  }
});

// Actualizar caso
router.put('/:id', auth, async (req, res) => {
  try {
    const { titulo, blocks, globalStyles } = req.body;
    const caso = await CaseStudy.findOne({ _id: req.params.id, user: req.user.id });
    if (!caso) {
      return res.status(404).json({ mensaje: 'Caso no encontrado' });
    }
    if (titulo) caso.titulo = titulo;
    if (blocks) caso.blocks = blocks;
    if (globalStyles) caso.globalStyles = globalStyles;
    await caso.save();
    return res.json(caso);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ mensaje: 'Error en el servidor' });
  }
});

// Eliminar caso
router.delete('/:id', auth, async (req, res) => {
  try {
    const caso = await CaseStudy.findOneAndDelete({ _id: req.params.id, user: req.user.id });
    if (!caso) {
      return res.status(404).json({ mensaje: 'Caso no encontrado' });
    }
    return res.json({ mensaje: 'Caso eliminado' });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ mensaje: 'Error en el servidor' });
  }
});

export default router;