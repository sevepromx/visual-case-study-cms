<template>
  <div>
    <h3 class="font-semibold mb-2">Propiedades del bloque</h3>
    <div v-if="block.type === 'header'" class="space-y-3">
      <div>
        <label class="block text-sm mb-1">Color de fondo</label>
        <input type="color" v-model="localProps.backgroundColor" />
      </div>
      <div>
        <label class="block text-sm mb-1">URL del logo (SVG o imagen)</label>
        <input type="text" v-model="localProps.logo" class="w-full border rounded px-2 py-1" />
      </div>
      <div>
        <label class="block text-sm mb-1">Tamaño del logo</label>
        <input type="range" min="20" max="200" v-model.number="localProps.logoSize" />
        <span class="text-xs">{{ localProps.logoSize }}px</span>
      </div>
      <div>
        <label class="block text-sm mb-1">Altura del header</label>
        <input type="range" min="40" max="200" v-model.number="localProps.height" />
        <span class="text-xs">{{ localProps.height }}px</span>
      </div>
    </div>
    <div v-else-if="block.type === 'text'" class="space-y-3">
      <div>
        <label class="block text-sm mb-1">Tag HTML</label>
        <select v-model="localProps.tag" class="border rounded px-2 py-1 w-full">
          <option value="h1">H1</option>
          <option value="h2">H2</option>
          <option value="h3">H3</option>
          <option value="h4">H4</option>
          <option value="p">Párrafo</option>
        </select>
      </div>
      <div>
        <label class="block text-sm mb-1">Contenido</label>
        <textarea v-model="localProps.content" class="w-full border rounded px-2 py-1" rows="4"></textarea>
      </div>
      <div>
        <label class="block text-sm mb-1">Tamaño de fuente</label>
        <input type="range" min="12" max="64" v-model.number="localProps.fontSize" />
        <span class="text-xs">{{ localProps.fontSize }}px</span>
      </div>
      <div>
        <label class="block text-sm mb-1">Color</label>
        <input type="color" v-model="localProps.color" />
      </div>
      <div>
        <label class="block text-sm mb-1">Alineación</label>
        <select v-model="localProps.align" class="border rounded px-2 py-1 w-full">
          <option value="left">Izquierda</option>
          <option value="center">Centro</option>
          <option value="right">Derecha</option>
        </select>
      </div>
    </div>
    <div v-else-if="block.type === 'comparison'" class="space-y-3">
      <div>
        <label class="block text-sm mb-1">Imagen antes</label>
        <input type="file" accept="image/*" @change="onFileChange($event, 'before')" />
        <div v-if="localProps.before" class="mt-2 text-xs text-green-600">Imagen seleccionada</div>
      </div>
      <div>
        <label class="block text-sm mb-1">Imagen después</label>
        <input type="file" accept="image/*" @change="onFileChange($event, 'after')" />
        <div v-if="localProps.after" class="mt-2 text-xs text-green-600">Imagen seleccionada</div>
      </div>
    </div>
    <div v-else-if="block.type === 'footer'" class="space-y-3">
      <div>
        <label class="block text-sm mb-1">Color de fondo</label>
        <input type="color" v-model="localProps.backgroundColor" />
      </div>
      <div>
        <label class="block text-sm mb-1">Color del texto</label>
        <input type="color" v-model="localProps.color" />
      </div>
      <div>
        <label class="block text-sm mb-1">Contenido</label>
        <textarea v-model="localProps.content" class="w-full border rounded px-2 py-1" rows="2"></textarea>
      </div>
    </div>
  </div>
</template>

<script setup>
import { reactive, watch, toRefs } from 'vue';
const props = defineProps({ block: Object });
const emit = defineEmits(['update']);

// Create a local copy of props to edit without mutating original immediately
const localProps = reactive({ ...props.block.props });

// Watch localProps and emit update when changed
watch(
  () => ({ ...localProps }),
  (val) => {
    emit('update', val);
  },
  { deep: true }
);

function onFileChange(event, field) {
  const file = event.target.files[0];
  if (file) {
    const reader = new FileReader();
    reader.onload = (e) => {
      localProps[field] = e.target.result;
    };
    reader.readAsDataURL(file);
  }
}
</script>