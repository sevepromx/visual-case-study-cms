<template>
  <footer :style="{
    backgroundColor: block.props.backgroundColor,
    color: block.props.color
  }" class="w-full text-center py-4">
    <span v-html="block.props.content"></span>
  </footer>
</template>

<script setup>
const props = defineProps({ block: Object });
</script>