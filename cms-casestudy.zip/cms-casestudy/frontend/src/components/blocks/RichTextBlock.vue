<template>
  <component
    :is="block.props.tag"
    :style="{
      fontSize: block.props.fontSize + 'px',
      color: block.props.color,
      textAlign: block.props.align
    }"
    v-html="block.props.content"
  ></component>
</template>

<script setup>
const props = defineProps({ block: Object });
</script>