<template>
  <div :style="styleObj" class="w-full flex items-center justify-center">
    <img v-if="block.props.logo" :src="block.props.logo" :style="{ height: block.props.logoSize + 'px' }" alt="logo" />
    <div v-else class="text-sm text-gray-500">Encabezado</div>
  </div>
</template>

<script setup>
import { computed } from 'vue';
const props = defineProps({ block: Object });

const styleObj = computed(() => ({
  backgroundColor: props.block.props.backgroundColor,
  height: props.block.props.height + 'px'
}));
</script>