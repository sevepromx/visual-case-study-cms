<template>
  <div class="w-full flex overflow-hidden">
    <div class="w-1/2 relative">
      <img v-if="block.props.before" :src="block.props.before" class="w-full h-full object-cover" />
      <div v-else class="h-40 flex items-center justify-center bg-gray-200 text-gray-500">Antes</div>
    </div>
    <div class="w-1/2 relative">
      <img v-if="block.props.after" :src="block.props.after" class="w-full h-full object-cover" />
      <div v-else class="h-40 flex items-center justify-center bg-gray-200 text-gray-500">Después</div>
    </div>
  </div>
</template>

<script setup>
const props = defineProps({ block: Object });
</script>