import { createRouter, createWebHistory } from 'vue-router';
import { useAuthStore } from '../store/auth.js';

// Lazy load views for better splitting
const LoginView = () => import('../views/LoginView.vue');
const RegisterView = () => import('../views/RegisterView.vue');
const DashboardView = () => import('../views/DashboardView.vue');
const EditorView = () => import('../views/EditorView.vue');
const PublicView = () => import('../views/PublicView.vue');

const routes = [
  {
    path: '/',
    redirect: '/dashboard'
  },
  {
    path: '/login',
    component: LoginView,
    meta: { guest: true }
  },
  {
    path: '/register',
    component: RegisterView,
    meta: { guest: true }
  },
  {
    path: '/dashboard',
    component: DashboardView,
    meta: { requiresAuth: true }
  },
  {
    path: '/editor/:id',
    component: EditorView,
    meta: { requiresAuth: true }
  },
  {
    path: '/view/:slug',
    component: PublicView
  }
];

const router = createRouter({
  history: createWebHistory(),
  routes
});

router.beforeEach((to, from, next) => {
  const auth = useAuthStore();
  if (to.meta.requiresAuth && !auth.loggedIn) {
    next('/login');
  } else if (to.meta.guest && auth.loggedIn) {
    next('/dashboard');
  } else {
    next();
  }
});

export default router;