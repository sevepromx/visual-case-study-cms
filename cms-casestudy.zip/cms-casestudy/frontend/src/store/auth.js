import { defineStore } from 'pinia';
import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || ''
});

export const useAuthStore = defineStore('auth', {
  state: () => ({
    token: localStorage.getItem('token') || null,
    usuario: localStorage.getItem('usuario') ? JSON.parse(localStorage.getItem('usuario')) : null
  }),
  getters: {
    loggedIn: (state) => !!state.token
  },
  actions: {
    setAuth(token, usuario) {
      this.token = token;
      this.usuario = usuario;
      localStorage.setItem('token', token);
      localStorage.setItem('usuario', JSON.stringify(usuario));
    },
    logout() {
      this.token = null;
      this.usuario = null;
      localStorage.removeItem('token');
      localStorage.removeItem('usuario');
    },
    async login(email, password) {
      const response = await api.post('/api/auth/login', { email, password });
      const { token, usuario } = response.data;
      this.setAuth(token, usuario);
    },
    async register(nombre, email, password) {
      await api.post('/api/auth/register', { nombre, email, password });
    }
  }
});

// Axios request interceptor to include token automatically
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export { api };