import { defineStore } from 'pinia';
import { api } from './auth.js';

export const useCaseStore = defineStore('caseStudies', {
  state: () => ({
    cases: [],
    currentCase: null,
    blocks: [],
    globalStyles: {
      backgroundColor: '#ffffff'
    },
    selectedIndex: null
  }),
  actions: {
    async fetchCases() {
      const res = await api.get('/api/case-studies');
      this.cases = res.data;
    },
    async getCaseById(id) {
      const res = await api.get(`/api/case-studies/${id}`);
      this.currentCase = res.data;
      this.blocks = res.data.blocks || [];
      this.globalStyles = res.data.globalStyles || { backgroundColor: '#ffffff' };
    },
    async createCase(titulo) {
      const res = await api.post('/api/case-studies', { titulo, blocks: [], globalStyles: { backgroundColor: '#ffffff' } });
      this.cases.unshift(res.data);
      return res.data;
    },
    async updateCase(id) {
      const payload = {
        titulo: this.currentCase.titulo,
        blocks: this.blocks,
        globalStyles: this.globalStyles
      };
      const res = await api.put(`/api/case-studies/${id}`, payload);
      // update local list
      const idx = this.cases.findIndex((c) => c._id === id);
      if (idx !== -1) {
        this.cases[idx] = res.data;
      }
    },
    clearCurrent() {
      this.currentCase = null;
      this.blocks = [];
      this.globalStyles = { backgroundColor: '#ffffff' };
      this.selectedIndex = null;
    },
    selectBlock(index) {
      this.selectedIndex = index;
    },
    addBlock(type) {
      // default props depending on block type
      let block = {};
      if (type === 'header') {
        block = { type: 'header', props: { backgroundColor: '#f5f5f5', logo: '', logoSize: 50, height: 80 } };
      } else if (type === 'text') {
        block = { type: 'text', props: { tag: 'h2', content: 'Texto de ejemplo', fontSize: 24, color: '#333333', align: 'left' } };
      } else if (type === 'comparison') {
        block = { type: 'comparison', props: { before: '', after: '' } };
      } else if (type === 'footer') {
        block = { type: 'footer', props: { backgroundColor: '#f5f5f5', color: '#333333', content: '© 2026' } };
      }
      this.blocks.push(block);
      this.selectedIndex = this.blocks.length - 1;
    },
    moveBlockUp(index) {
      if (index <= 0) return;
      const blocks = this.blocks;
      [blocks[index - 1], blocks[index]] = [blocks[index], blocks[index - 1]];
      this.selectedIndex = index - 1;
    },
    moveBlockDown(index) {
      if (index >= this.blocks.length - 1) return;
      const blocks = this.blocks;
      [blocks[index], blocks[index + 1]] = [blocks[index + 1], blocks[index]];
      this.selectedIndex = index + 1;
    },
    removeBlock(index) {
      this.blocks.splice(index, 1);
      this.selectedIndex = null;
    }
  }
});