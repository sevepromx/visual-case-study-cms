<template>
  <div :style="{ backgroundColor: caseData.globalStyles?.backgroundColor || '#ffffff' }" class="min-h-screen">
    <div v-if="loading" class="text-center py-20">Cargando...</div>
    <div v-else>
      <div v-for="(block, index) in caseData.blocks" :key="index" class="mb-4">
        <component :is="componentFor(block.type)" :block="block" />
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, defineAsyncComponent } from 'vue';
import { useRoute } from 'vue-router';
import axios from 'axios';

const route = useRoute();
const loading = ref(true);
const caseData = ref({ blocks: [], globalStyles: {} });

const componentMap = {
  header: defineAsyncComponent(() => import('../components/blocks/StickyHeaderBlock.vue')),
  text: defineAsyncComponent(() => import('../components/blocks/RichTextBlock.vue')),
  comparison: defineAsyncComponent(() => import('../components/blocks/ImageComparisonBlock.vue')),
  footer: defineAsyncComponent(() => import('../components/blocks/FooterBlock.vue'))
};

function componentFor(type) {
  return componentMap[type] || null;
}

onMounted(async () => {
  try {
    const res = await axios.get(`${import.meta.env.VITE_API_URL}/api/public/${route.params.slug}`);
    caseData.value = res.data;
  } catch (err) {
    console.error(err);
  } finally {
    loading.value = false;
  }
});
</script>