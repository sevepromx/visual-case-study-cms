<template>
  <div class="max-w-md mx-auto mt-16 p-6 bg-white rounded shadow">
    <h2 class="text-2xl font-bold mb-4 text-center">Registrarse</h2>
    <form @submit.prevent="handleRegister" class="space-y-4">
      <div>
        <label class="block text-sm font-medium mb-1">Nombre</label>
        <input v-model="nombre" type="text" class="w-full border rounded px-3 py-2" required />
      </div>
      <div>
        <label class="block text-sm font-medium mb-1">Correo electrónico</label>
        <input v-model="email" type="email" class="w-full border rounded px-3 py-2" required />
      </div>
      <div>
        <label class="block text-sm font-medium mb-1">Contraseña</label>
        <input v-model="password" type="password" class="w-full border rounded px-3 py-2" required />
      </div>
      <div v-if="mensaje" class="text-green-600 text-sm">{{ mensaje }}</div>
      <div v-if="error" class="text-red-600 text-sm">{{ error }}</div>
      <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded">Crear cuenta</button>
    </form>
    <p class="text-center text-sm mt-4">
      ¿Ya tienes cuenta? <router-link class="text-blue-600" to="/login">Inicia sesión</router-link>
    </p>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { useAuthStore } from '../store/auth.js';
import { useRouter } from 'vue-router';

const nombre = ref('');
const email = ref('');
const password = ref('');
const error = ref('');
const mensaje = ref('');

const auth = useAuthStore();
const router = useRouter();

async function handleRegister() {
  try {
    error.value = '';
    mensaje.value = '';
    await auth.register(nombre.value, email.value, password.value);
    mensaje.value = 'Cuenta creada correctamente. Ahora puedes iniciar sesión.';
    nombre.value = email.value = password.value = '';
    // optional redirect after register
    // router.push('/login');
  } catch (err) {
    error.value = err.response?.data?.mensaje || 'Error al registrarse';
  }
}
</script>