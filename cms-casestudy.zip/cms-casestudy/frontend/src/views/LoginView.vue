<template>
  <div class="max-w-md mx-auto mt-16 p-6 bg-white rounded shadow">
    <h2 class="text-2xl font-bold mb-4 text-center">Iniciar Sesión</h2>
    <form @submit.prevent="handleLogin" class="space-y-4">
      <div>
        <label class="block text-sm font-medium mb-1">Correo electrónico</label>
        <input v-model="email" type="email" class="w-full border rounded px-3 py-2" required />
      </div>
      <div>
        <label class="block text-sm font-medium mb-1">Contraseña</label>
        <input v-model="password" type="password" class="w-full border rounded px-3 py-2" required />
      </div>
      <div v-if="error" class="text-red-600 text-sm">{{ error }}</div>
      <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded">Ingresar</button>
    </form>
    <p class="text-center text-sm mt-4">
      ¿No tienes cuenta? <router-link class="text-blue-600" to="/register">Regístrate</router-link>
    </p>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { useAuthStore } from '../store/auth.js';
import { useRouter } from 'vue-router';

const email = ref('');
const password = ref('');
const error = ref('');

const auth = useAuthStore();
const router = useRouter();

async function handleLogin() {
  try {
    error.value = '';
    await auth.login(email.value, password.value);
    router.push('/dashboard');
  } catch (err) {
    error.value = err.response?.data?.mensaje || 'Error al iniciar sesión';
  }
}
</script>