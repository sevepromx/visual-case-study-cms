<template>
  <div class="flex h-full">
    <!-- Left Panel -->
    <aside class="w-40 bg-gray-100 p-4 border-r overflow-y-auto">
      <h3 class="font-semibold mb-2">Bloques</h3>
      <ul class="space-y-2">
        <li>
          <button @click="addBlock('header')" class="w-full px-2 py-1 bg-white border rounded hover:bg-gray-50">Encabezado</button>
        </li>
        <li>
          <button @click="addBlock('text')" class="w-full px-2 py-1 bg-white border rounded hover:bg-gray-50">Texto</button>
        </li>
        <li>
          <button @click="addBlock('comparison')" class="w-full px-2 py-1 bg-white border rounded hover:bg-gray-50">Comparación</button>
        </li>
        <li>
          <button @click="addBlock('footer')" class="w-full px-2 py-1 bg-white border rounded hover:bg-gray-50">Pie de página</button>
        </li>
      </ul>
    </aside>
    <!-- Canvas -->
    <section class="flex-1 p-4 overflow-y-auto" :style="{ backgroundColor: caseStore.globalStyles.backgroundColor }">
      <div
        v-for="(block, index) in caseStore.blocks"
        :key="index"
        :class="[
          'border rounded mb-4',
          caseStore.selectedIndex === index ? 'ring-2 ring-blue-500' : ''
        ]"
        @click="select(index)"
      >
        <!-- block preview -->
        <component :is="componentFor(block.type)" :block="block" />
        <!-- reorder buttons -->
        <div class="flex space-x-2 p-2 bg-gray-50 border-t text-sm">
          <button @click.stop="caseStore.moveBlockUp(index)" :disabled="index===0" class="px-2 py-1 bg-gray-200 rounded disabled:opacity-50">↑</button>
          <button @click.stop="caseStore.moveBlockDown(index)" :disabled="index===caseStore.blocks.length-1" class="px-2 py-1 bg-gray-200 rounded disabled:opacity-50">↓</button>
          <button @click.stop="caseStore.removeBlock(index)" class="ml-auto px-2 py-1 bg-red-500 text-white rounded">Eliminar</button>
        </div>
      </div>
      <div v-if="caseStore.blocks.length === 0" class="text-center text-gray-500 mt-20">Añade bloques desde la izquierda</div>
    </section>
    <!-- Inspector -->
    <aside class="w-64 bg-gray-100 p-4 border-l overflow-y-auto">
      <template v-if="caseStore.selectedIndex !== null">
        <Inspector
          :block="caseStore.blocks[caseStore.selectedIndex]"
          @update="updateBlock(caseStore.selectedIndex, $event)"
        />
      </template>
      <template v-else>
        <h3 class="font-semibold mb-2">Estilos globales</h3>
        <label class="block text-sm mb-1">Color de fondo</label>
        <input type="color" v-model="caseStore.globalStyles.backgroundColor" />
      </template>
      <button
        class="mt-6 w-full bg-green-600 hover:bg-green-700 text-white py-2 rounded"
        @click="guardar"
      >
        Guardar Cambios
      </button>
    </aside>
  </div>
</template>

<script setup>
import { onMounted, computed, defineAsyncComponent } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { useCaseStore } from '../store/caseStudies.js';

const route = useRoute();
const router = useRouter();
const caseStore = useCaseStore();

// load dynamic block components
const componentMap = {
  header: defineAsyncComponent(() => import('../components/blocks/StickyHeaderBlock.vue')),
  text: defineAsyncComponent(() => import('../components/blocks/RichTextBlock.vue')),
  comparison: defineAsyncComponent(() => import('../components/blocks/ImageComparisonBlock.vue')),
  footer: defineAsyncComponent(() => import('../components/blocks/FooterBlock.vue'))
};

function componentFor(type) {
  return componentMap[type] || null;
}

onMounted(async () => {
  await caseStore.getCaseById(route.params.id);
});

function addBlock(type) {
  caseStore.addBlock(type);
}

function select(index) {
  caseStore.selectBlock(index);
}

function updateBlock(index, newProps) {
  // update block props with newProps from inspector
  caseStore.blocks[index].props = { ...caseStore.blocks[index].props, ...newProps };
}

async function guardar() {
  await caseStore.updateCase(route.params.id);
  alert('Cambios guardados');
  router.push('/dashboard');
}
</script>

<script>
// Register Inspector component globally within this file
import { defineComponent } from 'vue';
export default {
  components: {
    Inspector: defineComponent(() => import('../components/Inspector.vue'))
  }
};
</script>