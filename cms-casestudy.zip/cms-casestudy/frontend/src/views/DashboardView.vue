<template>
  <div class="max-w-4xl mx-auto p-6">
    <div class="flex justify-between items-center mb-6">
      <h2 class="text-2xl font-bold">Tus Casos de Estudio</h2>
      <button
        @click="crearCaso"
        class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded"
      >
        Crear Nuevo Caso
      </button>
    </div>
    <div v-if="cargando" class="text-center py-10">Cargando...</div>
    <div v-else>
      <div v-if="cases.length === 0" class="text-center text-gray-600">Aún no tienes casos. Crea uno nuevo.</div>
      <ul class="space-y-4">
        <li
          v-for="caso in cases"
          :key="caso._id"
          class="p-4 bg-white shadow rounded flex justify-between items-center"
        >
          <div>
            <h3 class="font-semibold">{{ caso.titulo }}</h3>
            <p class="text-xs text-gray-500">Última edición: {{ formatoFecha(caso.updatedAt) }}</p>
          </div>
          <div class="space-x-2">
            <button
              @click="editar(caso)"
              class="bg-blue-500 hover:bg-blue-600 text-white px-3 py-1 rounded"
            >
              Editar
            </button>
            <router-link
              :to="`/view/${caso.slug}`"
              class="bg-gray-700 hover:bg-gray-800 text-white px-3 py-1 rounded"
            >
              Ver
            </router-link>
          </div>
        </li>
      </ul>
    </div>
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue';
import { useRouter } from 'vue-router';
import { useCaseStore } from '../store/caseStudies.js';

const caseStore = useCaseStore();
const router = useRouter();
const cases = caseStore.cases;
const cargando = ref(true);

onMounted(async () => {
  await caseStore.fetchCases();
  cargando.value = false;
});

function formatoFecha(date) {
  return new Date(date).toLocaleDateString('es-MX', { year: 'numeric', month: 'short', day: 'numeric' });
}

async function crearCaso() {
  const titulo = prompt('Título del nuevo caso');
  if (!titulo) return;
  const nuevo = await caseStore.createCase(titulo);
  router.push(`/editor/${nuevo._id}`);
}

function editar(caso) {
  router.push(`/editor/${caso._id}`);
}
</script>