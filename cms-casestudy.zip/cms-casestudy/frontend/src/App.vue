<template>
  <div class="min-h-screen flex flex-col">
    <header class="bg-white shadow-sm py-3 px-4 flex justify-between items-center">
      <h1 class="text-xl font-semibold">Visual Case Study CMS</h1>
      <button
        v-if="auth.loggedIn"
        @click="logout"
        class="text-sm text-red-600 hover:underline"
      >
        Cerrar Sesión
      </button>
    </header>
    <main class="flex-1">
      <router-view />
    </main>
  </div>
</template>

<script setup>
import { useAuthStore } from './store/auth.js';
import { useRouter } from 'vue-router';

const auth = useAuthStore();
const router = useRouter();

function logout() {
  auth.logout();
  router.push('/login');
}
</script>