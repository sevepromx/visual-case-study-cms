# Visual Case Study CMS

Este proyecto es un sistema completo de gestión de casos de estudio para médicos que permite crear páginas visuales mediante un editor de bloques. Incluye un backend en Node.js/Express con MongoDB y autenticación JWT, y un frontend en Vue 3 con Pinia, Tailwind CSS y Vue Router.

## Estructura del repositorio

- **`backend/`** – Contiene la API Express, los modelos de Mongoose y las rutas para autenticación y casos de estudio.
- **`frontend/`** – Contiene la aplicación Vue que implementa las pantallas de registro, inicio de sesión, panel de control, editor visual y vista pública.

## Despliegue rápido en Render

Haz clic en el siguiente botón para desplegar tu propia copia del proyecto en Render. Necesitarás una cuenta gratuita en Render y configurar tus variables de entorno (ver más abajo).

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy)

## Variables de entorno

Para el backend, crea un archivo `.env` basado en `.env.example` con las siguientes variables:

- **`MONGO_URI`**: Cadena de conexión de tu base de datos MongoDB.
- **`JWT_SECRET`**: Una cadena secreta para firmar los tokens JWT.
- **`PORT`**: Puerto en el que correrá el servidor (opcional, por defecto 5000).

Para el frontend, crea un archivo `.env` en la raíz de `frontend/` con:

```bash
VITE_API_URL=https://tu-backend.onrender.com
```

## Desarrollo local

1. Clona este repositorio:

   ```bash
   git clone <URL_DE_TU_REPO>
   cd visual-case-study-cms
   ```

2. Instala las dependencias del backend y frontend:

   ```bash
   cd backend
   npm install
   # Crea un archivo .env y configura tus variables
   cd ../frontend
   npm install
   # Crea un archivo .env y configura VITE_API_URL
   ```

3. Ejecuta el backend:

   ```bash
   cd backend
   npm start
   ```

4. En otra terminal ejecuta el frontend:

   ```bash
   cd frontend
   npm run dev
   ```

5. Accede a `http://localhost:5173` para ver la aplicación en desarrollo.

## Uso

1. Regístrate como usuario.
2. Inicia sesión para acceder al panel de control.
3. Crea un nuevo caso de estudio y usa el editor visual para añadir bloques (encabezado, texto, comparador, pie de página), reordenarlos y ajustar sus propiedades.
4. Guarda los cambios para persistir tu página.
5. Desde el panel de control puedes ver cada caso publicado en una URL pública (`/view/:slug`).

---

Desarrollado como parte de una misión de ingeniería de software.